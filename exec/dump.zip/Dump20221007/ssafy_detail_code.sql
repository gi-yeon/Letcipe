CREATE DATABASE  IF NOT EXISTS `ssafy` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ssafy`;
-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7a705.q.ssafy.io    Database: ssafy
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `detail_code`
--

DROP TABLE IF EXISTS `detail_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_code` (
  `id` varchar(10) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `header_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKfqak117yvt1ue7u70j5sy3rpy` (`header_id`),
  CONSTRAINT `FKfqak117yvt1ue7u70j5sy3rpy` FOREIGN KEY (`header_id`) REFERENCES `header_code` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_code`
--

LOCK TABLES `detail_code` WRITE;
/*!40000 ALTER TABLE `detail_code` DISABLE KEYS */;
INSERT INTO `detail_code` VALUES ('I0101','가루','I01'),('I0201','감자','I02'),('I0202','고구마','I02'),('I0301','돼지','I03'),('I0302','닭','I03'),('I0303','오리','I03'),('I0304','소','I03'),('I0305','기타','I03'),('I0401','밀가루','I04'),('I0402','찹쌀','I04'),('I0403','쌀','I04'),('I0404','보리','I04'),('I0405','옥수수','I04'),('I0406','현미','I04'),('I0407','밥','I04'),('I0408','기타','I04'),('I0409','전분','I04'),('I0501','감','I05'),('I0502','복숭아','I05'),('I0503','배','I05'),('I0504','포도','I05'),('I0505','파인애플','I05'),('I0506','키위','I05'),('I0507','사과','I05'),('I0508','바나나','I05'),('I0509','레몬','I05'),('I0510','망고','I05'),('I0511','딸기','I05'),('I0512','올리브','I05'),('I0513','밤','I05'),('I0514','베리','I05'),('I0515','귤','I05'),('I0516','기타','I05'),('I0601','과자','I06'),('I0701','국물','I07'),('I0702','육수','I07'),('I0801','기름','I08'),('I0901','기타','I09'),('I1001','달걀','I10'),('I1002','메추리알','I10'),('I1101','떡','I11'),('I1102','면','I11'),('I1201','두부','I12'),('I1202','묵','I12'),('I1301','빵','I13'),('I1401','생선포','I14'),('I1402','생선살','I14'),('I1403','생선','I14'),('I1404','게','I14'),('I1405','굴','I14'),('I1406','맛살','I14'),('I1407','멍게','I14'),('I1408','멸치','I14'),('I1409','조개','I14'),('I1410','새우','I14'),('I1411','어묵','I14'),('I1412','오징어','I14'),('I1413','젓','I14'),('I1414','낙지','I14'),('I1415','랍스터','I14'),('I1416','꼴뚜기','I14'),('I1417','문어','I14'),('I1418','미더덕','I14'),('I1419','다슬기','I14'),('I1420','기타','I14'),('I1501','두유','I15'),('I1502','크림','I15'),('I1503','버터','I15'),('I1504','아이스크림','I15'),('I1505','연유','I15'),('I1506','요거트','I15'),('I1507','요구르트','I15'),('I1508','우유','I15'),('I1509','치즈','I15'),('I1601','주류','I16'),('I1602','차','I16'),('I1603','커피','I16'),('I1604','물','I16'),('I1605','주스','I16'),('I1606','음료','I16'),('I1607','기타','I16'),('I1701','밀키트','I17'),('I1702','믹스','I17'),('I1703','만두','I17'),('I1704','음식','I17'),('I1705','기타','I17'),('I1801','장아찌','I18'),('I1802','피클','I18'),('I1901','장','I19'),('I1902','드레싱','I19'),('I1903','소스','I19'),('I1904','조미료','I19'),('I1905','향신료','I19'),('I1906','시럽','I19'),('I1907','액젓','I19'),('I1908','잼','I19'),('I2001','나물','I20'),('I2002','채소','I20'),('I2003','단무지','I20'),('I2004','김치','I20'),('I2005','버섯','I20'),('I2101','마시멜로','I21'),('I2102','젤리','I21'),('I2103','초콜릿','I21'),('I2104','캐러멜','I21'),('I2105','판젤라틴','I21'),('I2106','사탕','I21'),('I2201','견과류','I22'),('I2202','깨','I22'),('I2203','콩','I22'),('I2204','잣','I22'),('I2205','호두','I22'),('I2206','팥','I22'),('I2207','기타','I22'),('I2208','아몬드','I22'),('I2301','김','I23'),('I2302','다시마','I23'),('I2303','미역','I23'),('I2304','파래','I23'),('I2401','햄','I24'),('I2402','소시지','I24'),('I2403','베이컨','I24'),('I2404','돈가스','I24'),('R0001','밥요리','R00'),('R0002','국 탕','R00'),('R0003','찌개 전골','R00'),('R0004','밑반찬','R00'),('R0005','볶음요리','R00'),('R0006','구이(고기/생선)','R00'),('R0007','찜 조림','R00'),('R0008','손님상','R00'),('R0009','아이반찬','R00'),('R0010','김치 장아찌','R00'),('R0011','도시라','R00'),('R0012','튀김','R00'),('R0013','면요리','R00'),('R0014','샐러드','R00'),('R0015','김밥 초밥','R00'),('R0016','야식 술안주','R00'),('R0017','스파게티','R00'),('R0018','간식 분식','R00'),('R0019','토스트 샌드위치','R00'),('R0020','베이킹','R00'),('R0021','디저트','R00'),('R0022','주스 음료','R00'),('R0023','술 칵테일','R00'),('R0024','명절요리','R00'),('R0025','기타요리','R00');
/*!40000 ALTER TABLE `detail_code` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07  9:37:57
