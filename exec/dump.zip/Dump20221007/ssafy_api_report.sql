CREATE DATABASE  IF NOT EXISTS `ssafy` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ssafy`;
-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7a705.q.ssafy.io    Database: ssafy
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_report`
--

DROP TABLE IF EXISTS `api_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_report` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `count` int DEFAULT NULL,
  `date` date DEFAULT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cart_report_constraint` (`date`,`method_name`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_report`
--

LOCK TABLES `api_report` WRITE;
/*!40000 ALTER TABLE `api_report` DISABLE KEYS */;
INSERT INTO `api_report` VALUES (10,3,'2022-09-29','checkIdDuplicate'),(11,3,'2022-09-29','getComment'),(12,6,'2022-09-29','loginUser'),(13,5,'2022-09-29','readUser'),(14,69,'2022-09-29','searchIngredient'),(15,6,'2022-09-29','searchRecipe'),(16,4,'2022-10-04','checkIdDuplicate'),(17,3,'2022-10-04','checkNicknameDuplicate'),(18,3,'2022-10-04','createCart'),(19,3,'2022-10-04','createCartHistory'),(20,8,'2022-10-04','createRecipeBookmark'),(21,74,'2022-10-04','createRecipeLike'),(22,2,'2022-10-04','createRecipeList'),(23,1,'2022-10-04','createUser'),(24,12,'2022-10-04','deleteRecipe'),(25,7,'2022-10-04','deleteRecipeBookmark'),(26,74,'2022-10-04','deleteRecipeLike'),(27,52,'2022-10-04','getBestRecipeList'),(28,35,'2022-10-04','getCartIngredient'),(29,156,'2022-10-04','getCartReport'),(30,36,'2022-10-04','getComment'),(31,36,'2022-10-04','getCommentNum'),(32,17,'2022-10-04','getHistory'),(33,108,'2022-10-04','getHistoryList'),(34,3,'2022-10-04','getImage'),(35,40,'2022-10-04','getRecipe'),(36,2,'2022-10-04','getRecipeList'),(37,134,'2022-10-04','getRecipeRecommend'),(38,13,'2022-10-04','loginUser'),(39,1,'2022-10-04','patchBoardComment'),(40,1,'2022-10-04','postComment'),(41,65,'2022-10-04','readCart'),(42,36,'2022-10-04','readRecipe'),(43,7,'2022-10-04','readRecipeBookmark'),(44,17,'2022-10-04','readRecipeLike'),(45,13,'2022-10-04','readUser'),(46,42,'2022-10-04','readUserRecipe'),(47,16,'2022-10-04','readUserRecipeList'),(48,104,'2022-10-04','searchHot'),(49,14,'2022-10-04','searchIngredient'),(50,22,'2022-10-04','searchRecipe'),(51,5,'2022-10-04','searchRecipeList'),(52,3,'2022-10-04','sendOne'),(53,13,'2022-10-04','totalNumRecipe'),(54,6,'2022-10-04','updateHistory'),(55,291,'2022-10-05','checkHistoryIngredient'),(56,4,'2022-10-05','checkIdDuplicate'),(57,3,'2022-10-05','checkNicknameDuplicate'),(58,30,'2022-10-05','createCart'),(59,2,'2022-10-05','createCartHistory'),(60,5,'2022-10-05','createRecipe'),(61,7,'2022-10-05','createRecipeBookmark'),(62,11,'2022-10-05','createRecipeLike'),(63,9,'2022-10-05','createRecipeList'),(64,3,'2022-10-05','createRecipeListBookmark'),(65,3,'2022-10-05','createUser'),(66,21,'2022-10-05','deleteCart'),(67,3,'2022-10-05','deleteCartIngredient'),(68,19,'2022-10-05','deleteRecipe'),(69,3,'2022-10-05','deleteRecipeBookmark'),(70,6,'2022-10-05','deleteRecipeLike'),(71,4,'2022-10-05','deleteRecipeList'),(72,1,'2022-10-05','deleteRecipeListBookmark'),(73,36,'2022-10-05','deleteRecipeListItem'),(74,74,'2022-10-05','getBestRecipeList'),(75,113,'2022-10-05','getCartIngredient'),(76,222,'2022-10-05','getCartReport'),(77,97,'2022-10-05','getComment'),(78,131,'2022-10-05','getCommentNum'),(79,128,'2022-10-05','getHistory'),(80,308,'2022-10-05','getHistoryList'),(81,181,'2022-10-05','getImage'),(82,11,'2022-10-05','getRecipe'),(83,67,'2022-10-05','getRecipeList'),(84,118,'2022-10-05','getRecipeRecommend'),(85,33,'2022-10-05','getUserComment'),(86,25,'2022-10-05','loginUser'),(87,2,'2022-10-05','patchBoardComment'),(88,56,'2022-10-05','patchCartIngredient'),(89,6,'2022-10-05','postComment'),(90,2,'2022-10-05','postReview'),(91,19,'2022-10-05','putReview'),(92,149,'2022-10-05','readCart'),(93,92,'2022-10-05','readRecipe'),(94,4,'2022-10-05','readRecipeBookmark'),(95,16,'2022-10-05','readRecipeLike'),(96,4,'2022-10-05','readRecipeListBookmark'),(97,82,'2022-10-05','readUser'),(98,33,'2022-10-05','readUserRecipe'),(99,98,'2022-10-05','readUserRecipeList'),(100,146,'2022-10-05','searchHot'),(101,183,'2022-10-05','searchIngredient'),(102,64,'2022-10-05','searchRecipe'),(103,13,'2022-10-05','searchRecipeList'),(104,4,'2022-10-05','sendOne'),(105,71,'2022-10-05','totalNumRecipe'),(106,2,'2022-10-05','updateCartRecipe'),(107,2,'2022-10-05','updateRecipeList'),(108,2,'2022-10-05','updateUser');
/*!40000 ALTER TABLE `api_report` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07  9:37:52
