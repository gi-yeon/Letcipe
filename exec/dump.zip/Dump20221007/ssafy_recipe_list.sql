CREATE DATABASE  IF NOT EXISTS `ssafy` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ssafy`;
-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7a705.q.ssafy.io    Database: ssafy
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recipe_list`
--

DROP TABLE IF EXISTS `recipe_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recipe_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `is_deleted` int NOT NULL,
  `is_shared` int DEFAULT NULL,
  `mod_time` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `reg_time` datetime DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKghd0ngvanivxq9139aptq7r6e` (`user_id`),
  CONSTRAINT `FKghd0ngvanivxq9139aptq7r6e` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipe_list`
--

LOCK TABLES `recipe_list` WRITE;
/*!40000 ALTER TABLE `recipe_list` DISABLE KEYS */;
INSERT INTO `recipe_list` VALUES (4,'테스팅',1,1,NULL,'테스트','2022-10-05 11:27:52',1),(5,'ㅎㅇㅎㅇ',1,1,NULL,'ㅎㅇㅎㅇ','2022-10-05 13:10:30',11),(14,'2',1,1,NULL,'ㅎㅇ','2022-10-05 23:48:10',10),(15,'2',1,0,NULL,'삭제테스트','2022-10-06 00:27:00',10),(17,'z',1,1,NULL,'asd','2022-10-05 15:48:51',10),(18,'asdf',1,1,NULL,'temp','2022-10-06 00:38:41',10),(19,'aa',1,1,NULL,'temp1','2022-10-06 00:38:57',10),(20,'asdf',1,1,NULL,'asdf','2022-10-06 00:39:05',10),(21,'',1,1,NULL,'temp1','2022-10-06 02:12:43',10),(22,'양파덥덥',1,1,NULL,'양파덥덥','2022-10-06 11:48:50',1),(23,'테스트',1,0,NULL,'테스트','2022-10-06 11:50:05',1),(24,'양파',1,1,NULL,'양파','2022-10-06 11:55:28',1),(25,'존맛탱',1,1,NULL,'히히 맛있겠다','2022-10-06 12:45:45',1),(26,'만들어',1,1,NULL,'만들어요','2022-10-06 12:49:42',1),(27,'asd',1,1,NULL,'asd','2022-10-06 12:50:46',1),(28,'sdf',1,1,NULL,'sdf','2022-10-06 12:50:58',1),(29,'',1,1,NULL,'볶','2022-10-06 04:06:28',10),(30,'ㅁㄴㅇㄹ',1,1,NULL,'ㅁㄴㅇㄹ','2022-10-06 04:12:56',10),(31,'ㅋㅌㅊㅍ',1,1,NULL,'ㅁㄴㅇㄹㅇ','2022-10-06 04:13:51',10),(32,'',1,1,NULL,'ㅂㅂㄴ','2022-10-06 04:18:45',10),(33,'ㅅㄷㅅㄷㅅ',1,1,NULL,'ㅅㄷㅅㄷ','2022-10-06 04:36:41',10),(34,'ㅁㄴㅇㄹ',1,1,NULL,'ㅁㄴㅇㄹ','2022-10-06 04:40:11',10),(35,'카피카피',1,0,NULL,'히히 카피캣','2022-10-06 16:55:36',6),(36,'맛나용',1,0,NULL,'준성스 리스트','2022-10-06 16:58:10',7),(37,'리스트',1,1,NULL,'세개짜리','2022-10-06 16:58:44',7),(38,'1',1,1,NULL,'test1','2022-10-07 00:46:13',1),(39,'1',1,1,NULL,'123','2022-10-07 00:47:01',1),(40,'1',1,1,NULL,'asd','2022-10-07 00:50:50',1),(41,'asd',1,1,NULL,'123','2022-10-07 00:51:14',1),(42,'1212',1,0,NULL,'sdasd','2022-10-07 01:03:22',11),(43,'비가 추적추적 오는 날 좋은 요리들',0,0,NULL,'비오는 날에는','2022-10-07 01:47:30',14),(44,'1',1,1,NULL,'asd','2022-10-07 01:56:32',11),(45,'요거면 든든~',1,1,NULL,'준성쓰 레시피리스트','2022-10-07 02:19:40',7),(46,'1',1,1,NULL,'gd','2022-10-06 18:09:58',11),(47,'1',1,1,NULL,'gdgd','2022-10-06 18:15:50',11),(48,'',1,1,NULL,'asdf','2022-10-06 19:27:19',10);
/*!40000 ALTER TABLE `recipe_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07  9:37:55
