CREATE DATABASE  IF NOT EXISTS `ssafy` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ssafy`;
-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: j7a705.q.ssafy.io    Database: ssafy
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `birth` date NOT NULL,
  `email` varchar(40) NOT NULL,
  `family` int DEFAULT NULL,
  `gender` int NOT NULL,
  `job` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `is_deleted` int NOT NULL,
  `user_id` varchar(30) NOT NULL,
  `user_type` int NOT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'1997-03-17','admin@admin.com',4,0,2,'admin','admin','9e060f507b01f5cc096fea85ddf6ce6763898f33c24456a0752eabebd38317a5','010-8756-2387','https://j7a705.q.ssafy.io/api/image/f5460885-f63b-455a-a09b-b85202e66df3.jpg',0,'adminn',1,NULL),(4,'1997-03-17','a@a.com',4,0,2,'a','a','9834876dcfb05cb167a5c24953eba58c4ac89b1adf57f28f2f9d09af107ee8f0','010-8756-2387',NULL,0,'a',0,NULL),(6,'1997-03-17','osj2387@naver.com',4,0,0,'오성준','blonde','c49a6411ced39dd754d795a293a5d416578ae7abd3f955ab2f46e212cc9edb77','01012345678','https://j7a705.q.ssafy.io/api/image/f26c8589-4fa4-4049-b98c-bcdae4c4856c.png',0,'osj2387',0,NULL),(7,'1996-07-27','junsung@letcipe.com',1,0,2,'이준성','jun','823cd281a4ea507129964532c96dda1a4f5e3dbab9c95f00e7eeb72afa09c1fe','01092291015','https://j7a705.q.ssafy.io/api/image/929d6541-92d0-472b-9301-cec41e0ea2e2.png',0,'junsung',0,NULL),(8,'1996-07-27','sss@ddd.com',1,0,1,'이준성','juns','679735a3aaa74b0822d0e9fec487f895500f6d4cbe320dbcfc5204b6916a7be8','01092291015','https://j7a705.q.ssafy.io/api/image/ba1eff4e-6197-4fac-8a6c-5a3f16f80543.png',0,'junsung2',0,NULL),(9,'2006-08-23','osj@naver.com',3,0,0,'오상준','ohsun','276608a87fcf1a9047fd398d47354285cdd484342edb3a42fabca7fb221a42f8','01087562387','https://j7a705.q.ssafy.io/api/image/be621df7-9fe1-481b-b31c-a8278a621f45.jpg',0,'ohsungjoon',0,NULL),(10,'1997-12-04','giyeon@giyeon.com',1,0,0,'정기연','하이안녕','eafb89b548cbda32e38f7170bb859c8733cd30bb0e301b0161177390fd6bb4e8','01064503145','https://j7a705.q.ssafy.io/api/image/96dd7e8f-f75a-44f0-afa6-fc224e0e1e3f.jpg',0,'giyeon',0,NULL),(11,'2022-10-05','ssafy705@naver.com',1,0,0,'a705','letcipe','486fbbae3f8ac7441695d39ffdcef0c4ff09a84b50606c52c21ca7ba70c06f2e','01030935583','https://j7a705.q.ssafy.io/api/image/fb142fd0-e21f-4aeb-87d5-1b81bdeba2b9.jpg',0,'ssafy7',0,NULL),(12,'1999-07-12','parkjisu@naver.com',4,0,0,'박지수','지수박','93bdafa29ab4967a4984cba8e6552c83926c5d2b9933c7bc25abf11155edad23','01055329063','https://j7a705.q.ssafy.io/api/image/a212af8e-fd4c-4352-bf31-7dae5017a024.png',0,'parkjisu',0,NULL),(13,'2022-10-06','aa@naver.com',4,0,0,'박지수','지수박수','ab99460ed1cfc824fc2265e20f3e37548818239347d0c9541a5358ff30f8d6c0','01055329063','https://j7a705.q.ssafy.io/api/image/17f3b2a3-9044-4c83-ae29-6d89945e677b.png',0,'admina',0,NULL),(14,'1999-07-12','abc@naver.com',2,1,0,'박지수','지수박수박','5950044446901c31b365a8a7e589033331d0727e96bdf9f89843056e8b07b488','01055329063','https://j7a705.q.ssafy.io/api/image/1b73d664-1dc1-4bf9-b52c-89b57fe3476d.png',0,'mnmjjangmat',0,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07  9:37:53
